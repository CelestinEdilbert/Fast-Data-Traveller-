/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * mainframe.java
 *
 * Created on 18 Jul, 2017, 7:56:56 PM
 */

package SOURCE;

import java.awt.Desktop;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author CELESTIN EDILBERT
 */
public class CatchFrame extends javax.swing.JFrame {
    float kb,mb,gb,temp;
 String types[]=new String[]{" KB"," MB"," GB"};int ins,ins1;
 String file4;int netvalue,jp4,netvalue1=0;
 int pv,loop=0,totalfiles=1;

    /** Creates new form mainframe */
    public CatchFrame() {
        try {
            try {
                initComponents();
               
                 jButton4.setVisible(false);
                jButton5.setVisible(false);
                FileReader fr = null;
                char[] sname1 = new char[31];
                fr = new FileReader("C:\\Fadattra\\Settings\\name.tcs");
                for (int i = 0, j = 0; (i = fr.read()) != -1; i++, j++) {
                    if ((char) i == '|') {
                    } else {
                        sname1[j] = (char) i;
                    }
                }
                fr.close();
                String sname2 = new String(sname1);
                jLabel2.setText((String) sname2);
            } catch (IOException ex) {
                Logger.getLogger(CatchFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
            String ipad;
            InetAddress ind = InetAddress.getLocalHost();
            ipad = (String) (ind.getHostAddress());
            jLabel11.setText("Catcher's IP Address");
            jLabel10.setText(ipad);
        } catch (UnknownHostException ex) {
            Logger.getLogger(CatchFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.repaint();
        Thread t=new Thread(new Runnable(){
            private long starttime;
            private long starttime1;
            
            public void run(){
                try {
                    File dir = new File("C:\\Fadattra\\FileBucket\\");
                    Boolean exists = dir.exists();
                    if (exists == true) {
                    } else {
                        new File("C:\\Fadattra\\FileBucket\\").mkdirs();
                    }
                    
                    
                    ServerSocket ssock = new ServerSocket(5000);
                    for (int loop = 0; loop < totalfiles; loop++) {
                        
                            System.out.println("vinow");
                        Socket socket = ssock.accept();
                        if(loop==0)
                            starttime = System.nanoTime();
                    try {
                        
                        
                            
                            DataInputStream dis2 = new DataInputStream(socket.getInputStream());
                            String file1;
                            file1 = String.valueOf(dis2.readUTF());
                            System.out.println(file1);
                            char[] dname = file1.toCharArray();
                            int i;
                            for (i = 0; i < file1.length(); i++) {
                                if (dname[i] == '|') {
                                    break;
                                }
                            }
                            char[] check = new char[i];
                            int j;
                            for (j = 0; j < i; j++) {
                                check[j] = dname[j];
                                System.out.print(check[j]);
                            }
                            String devicename = new String(check);
                            jLabel9.setText("Connected to:");
                            jLabel7.setText(devicename);
                            char[] file2 = file1.toCharArray();
                            int fie = 0;
                            for (i = file2.length - 1; i != 0; i--) {
                                if (file2[i] == '\\') {
                                    break;
                                } else {
                                    fie = i;
                                }
                            }
                            char[] file3 = new char[file2.length - fie];
                            for (i = fie, j = 0; i < file2.length; i++, j++) {
                                file3[j] = file2[i];
                            }
                            file4 = new String(file3);
                            jLabel3.setText(file4);
                            jLabel12.setText("Filename:");
                            jLabel15.setText("File Size:");
                            FileOutputStream fos;
                            fos = new FileOutputStream("C:\\Fadattra\\FileBucket\\" + ((String) file4));
                            BufferedOutputStream bos = new BufferedOutputStream(fos);
                            InputStream is = socket.getInputStream();
                            int[] filesize = new int[99];
                            int bytesRead = 0;
                            int starter = 0;
                            long temp3 = 0;
                            long temp6 = 0;
                           
                            for (i = 0; i < file2.length - 1; i++) {
                                if (file2[i] == '?') {
                                    i++;
                                    for (; file2[i] != '?'; i++) {
                                        temp3 = (Character.getNumericValue(file2[i]));
                                        temp6 = (temp3 + temp6 * 10);
                                    }
                                }
                            }
                            totalfiles = (int) temp6;
                            System.out.println(totalfiles);
                            long fls = 0;
                            long g = 1;
                            long gi = 1;
                            long temp1 = 0;
                            int q = 0;
                            for (i = 0, j = 0; file2[i] != ':'; i++) {
                                starter = i;
                            }
                            starter++;
                            for (i = starter; file2[i] != ';'; i++) {
                                if (file2[i] == ':') {
                                } else {
                                    filesize[j] = Character.getNumericValue(file2[i]);
                                    j++;
                                }
                            }
                            for (i = j - 1, q = 0; i >= 0; i--, q++) {
                                g = g * 10;
                                if (gi == 1) {
                                    g = 1;
                                    gi++;
                                }
                                temp1 = filesize[i] * g;
                                fls = fls + temp1;
                            }
                            long fileLength = fls;
                            starttime1 = System.nanoTime();
                            jButton4.setVisible(false);
                            jLabel11.setVisible(false);
                            jLabel10.setVisible(false);
                            byte[] contents2 = new byte[9999999];
                            long temp4 = 0;
                            float temp5 = 0;
                             jLabel18.setText((loop+1)+" Of "+totalfiles);
                            while ((bytesRead = is.read(contents2)) != -1) {
                                temp4 = bytesRead + temp4;
                                temp5 = temp4;
                                bos.write(contents2, 0, bytesRead);
                                long speedcheck = (int) ((System.nanoTime()-starttime1)/1000000000);
                                jLabel16.setText("Speed:");
                                if (speedcheck != 0) {
                                    float bps = temp4 / speedcheck;
                                    float kbps = bps / 1024;
                                    int mbps = (int) kbps / 1024;
                                    jLabel17.setText(mbps + " Mbps");
                                }
                                if (temp4 >= 1024) {
                                    temp = temp4 / 1024;
                                    kb = temp;
                                    ins = 0;
                                    if (kb >= 1024) {
                                        temp = kb / 1024;
                                        mb = temp;
                                        ins = 1;
                                    }
                                    if (mb >= 1024) {
                                        temp = mb / 1024;
                                        gb = temp;
                                        ins = 2;
                                    }
                                    ins1 = ins;
                                    jLabel13.setText(temp + types[ins]);
                                    ins = 0;
                                }
                                pv = (int) ((temp5 * 100) / fileLength);
                               
                                jLabel14.setText(String.valueOf(pv) + "%");
                                jProgressBar4.setValue(pv);
                                Thread t1 = new Thread(new Runnable() {

                                    public void run() {
                                        if (pv == 9) {
                                            if (file4.endsWith(".mp4") || file4.endsWith(".mov") || file4.endsWith(".mkv")) {
                                                jLabel4.setText("Opening Media Files");
                                                try {
                                                    Desktop.getDesktop().open(new File("C:\\Fadattra\\FileBucket\\" + file4));
                                                } catch (IOException ex) {
                                                    Logger.getLogger(CatchFrame.class.getName()).log(Level.SEVERE, null, ex);
                                                }
                                            }
                                        }
                                        if (pv > 21) {
                                            jLabel4.setText(" ");
                                        }
                                    }
                                });
                                FileReader fr = new FileReader("C:\\Fadattra\\Settings\\video.tcs");
                                for (int c = 0; (c = fr.read()) != -1; c++) {
                                    if ((char) c == '1') {
                                        t1.start();
                                    }
                                }
                            }
                            jButton5.setVisible(true);
                             socket.close();
                              bos.close();
                              bos.flush();
                              fos.close();
                              fos.flush();
                            is.close();
                            
                            
                           
                           
                            
                   if(loop==0){
                  jProgressBar3.setMinimum(0);
                jProgressBar3.setMaximum(totalfiles);}
                 jProgressBar3.setValue(loop+1);
                        
                    } catch (IOException ex) {
                        Logger.getLogger(CatchFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }}
                    long endtime = System.nanoTime() - starttime;
                    float seconds = (int) ((float) endtime / 1000000000.0);
                    System.out.println(endtime);
                    if (seconds >= 60) {
                        float mins = seconds / 60;
                        jLabel5.setText("Elapsed Time:" + mins + " Mins");
                    } else {
                        jLabel5.setText("Elapsed Time:" + seconds + " secs");
                    }
                    jLabel13.setText(temp + types[ins1]);
                    //jProgressBar3.setValue(100);
                    jLabel4.setText("File Saved Successfully");
                } catch (IOException ex) {
                    Logger.getLogger(CatchFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }});
        t.start();
        this.repaint();
        }

        
        
                

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jProgressBar3 = new javax.swing.JProgressBar();
        jButton4 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jProgressBar4 = new javax.swing.JProgressBar();
        jLabel10 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("FADATTRA");
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Century Gothic", 0, 24));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 500, 360, 40));

        jProgressBar3.setBackground(new java.awt.Color(51, 51, 51));
        jProgressBar3.setForeground(new java.awt.Color(0, 255, 0));
        jProgressBar3.setBorderPainted(false);
        jProgressBar3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jProgressBar3.setVerifyInputWhenFocusTarget(false);
        jPanel1.add(jProgressBar3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 500, 990, 40));

        jButton4.setBackground(new java.awt.Color(0, 0, 0));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SOURCE/button cop1y.png"))); // NOI18N
        jButton4.setToolTipText("Throw the File");
        jButton4.setBorder(null);
        jButton4.setBorderPainted(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setSelected(true);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 190, 280, 270));

        jLabel12.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 204, 204));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 160, 40));

        jLabel7.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 102, 0));
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 530, 40));

        jLabel9.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 190, 40));

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 120, 20));

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setForeground(new java.awt.Color(153, 153, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SOURCE/back2.png"))); // NOI18N
        jButton3.setToolTipText("BACK");
        jButton3.setBorder(null);
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 50, 50));

        jPanel2.setBackground(new java.awt.Color(0, 102, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), null, null, new java.awt.Color(0, 204, 204)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Clear Sans Thin", 1, 24));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setToolTipText("Device Name");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 420, 30));

        jLabel1.setFont(new java.awt.Font("Century Gothic", 0, 74));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SOURCE/fadattra.png"))); // NOI18N
        jLabel1.setToolTipText("Home");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 13, 440, 150));
        jPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 93, -1, -1));
        jPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 93, -1, -1));
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 33, 120, 99));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setForeground(new java.awt.Color(153, 153, 153));
        jButton1.setToolTipText("BACK");
        jButton1.setBorder(null);
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 60, 60));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -7, 1000, 120));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, -1, -1));
        jPanel1.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, -1));

        jLabel13.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 102, 0));
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, 410, 40));

        jLabel4.setFont(new java.awt.Font("Century Gothic", 0, 36));
        jLabel4.setForeground(new java.awt.Color(153, 153, 153));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 990, 60));

        jButton5.setBackground(new java.awt.Color(51, 51, 51));
        jButton5.setFont(new java.awt.Font("Century Gothic", 0, 10));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SOURCE/openfolder.png"))); // NOI18N
        jButton5.setToolTipText("Open Folder");
        jButton5.setBorderPainted(false);
        jButton5.setOpaque(false);
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, 70, 60));

        jLabel14.setFont(new java.awt.Font("Century Gothic", 0, 251)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 0, 0));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 170, 630, 280));

        jLabel16.setFont(new java.awt.Font("Century Gothic", 0, 24));
        jLabel16.setForeground(new java.awt.Color(204, 204, 204));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 100, 40));

        jLabel15.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(204, 204, 204));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 110, 40));

        jLabel17.setFont(new java.awt.Font("Century Gothic", 0, 24));
        jLabel17.setForeground(new java.awt.Color(255, 102, 0));
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, 280, 40));

        jProgressBar4.setBackground(new java.awt.Color(51, 51, 51));
        jProgressBar4.setForeground(new java.awt.Color(0, 204, 0));
        jProgressBar4.setBorderPainted(false);
        jProgressBar4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jProgressBar4.setRequestFocusEnabled(false);
        jPanel1.add(jProgressBar4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, 990, 10));

        jLabel10.setFont(new java.awt.Font("Century Gothic", 0, 74));
        jLabel10.setForeground(new java.awt.Color(204, 204, 204));
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 690, 70));

        jLabel18.setFont(new java.awt.Font("Century Gothic", 0, 24));
        jLabel18.setForeground(new java.awt.Color(255, 102, 0));
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 374, 350, 50));

        jLabel3.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 102, 0));
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 240, 860, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 540));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
       dispose();
        mainframe mf=new mainframe();
        mf.setVisible(true);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        dispose();
        mainframe mf = new mainframe();
        mf.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        dispose();
        mainframe mf = new mainframe();
        mf.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

try{
            Desktop.getDesktop().open(new File("C:\\Fadattra\\FileBucket\\"));
        } catch (IOException ex) {
            Logger.getLogger(CatchFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
  

 
}//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        jLabel4.setText("Opening File Bucket");
    }//GEN-LAST:event_jButton5MouseClicked

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CatchFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JProgressBar jProgressBar3;
    private javax.swing.JProgressBar jProgressBar4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    // End of variables declaration//GEN-END:variables

}
